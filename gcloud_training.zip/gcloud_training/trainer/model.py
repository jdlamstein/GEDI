#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Sep 23 15:42:12 2018

https://github.com/selimsef/dsb2018_topcoders/blob/master/victor/models.py
Densenet
https://github.com/tdeboissiere/DeepLearningImplementations/tree/master/DenseNet

@author: joshualamstein
"""
from keras.optimizers import Adam, RMSprop
from keras.models import Model
from keras.layers import Dropout
from keras.layers import Input, BatchNormalization, Conv2D, MaxPooling2D, AveragePooling2D, ZeroPadding2D, Concatenate, UpSampling2D, Activation
from keras.layers import Conv2DTranspose
from keras.layers.merge import concatenate
#from keras.losses import categorical_crossentropy
#from keras.applications.inception_resnet_v2 import InceptionResNetV2, inception_resnet_block, conv2d_bn
#from keras.applications.densenet import DenseNet121, dense_block, transition_block
from keras_applications.densenet import DenseNet121, dense_block, transition_block
from keras_applications.inception_resnet_v2 import InceptionResNetV2, inception_resnet_block, conv2d_bn
from trainer.loss import dice_coef, dice_coef_loss, jaccard, make_loss, binary_crossentropy, hard_dice_coef_ch1, softmax_dice_loss, dice_coef_rounded_ch0, dice_coef_rounded_ch1
import trainer.param as p


bn_axis = 3
channel_axis = bn_axis

def schedule_steps(epoch, steps):
    for step in steps:
        if step[1] > epoch:
            print("Setting learning rate to {}".format(step[0]))
            return step[0]
    print("Setting learning rate to {}".format(steps[-1][0]))
    return steps[-1][0]
        
#def dice_coef(y_true, y_pred):
#    y_true_f = K.flatten(y_true)
#    y_pred_f = K.flatten(y_pred)
#    intersection = K.sum(y_true_f * y_pred_f)
#    return (2. * intersection + 1) / (K.sum(y_true_f) + K.sum(y_pred_f) + 1)
#
#def dice_coef_loss(y_true, y_pred):
#    return 1 - (dice_coef(y_true, y_pred))

def conv_block(prev, num_filters, kernel=(3, 3), strides=(1, 1), act='relu', prefix=None):
    name = None
    if prefix is not None:
        name = prefix + '_conv'
    conv = Conv2D(num_filters, kernel, padding='same', kernel_initializer='he_normal', strides=strides, name=name)(prev)
    if prefix is not None:
        name = prefix + '_norm'
    conv = BatchNormalization(name=name, axis=bn_axis)(conv)
    if prefix is not None:
        name = prefix + '_act'
    conv = Activation(act, name=name)(conv)
    return conv


def to_savedmodel(model, export_path):
  """Convert the Keras HDF5 model into TensorFlow SavedModel."""

  builder = saved_model_builder.SavedModelBuilder(export_path)

  signature = predict_signature_def(
      inputs={'input': model.inputs[0]}, outputs={'income': model.outputs[0]})

  with K.get_session() as sess:
    builder.add_meta_graph_and_variables(
        sess=sess,
        tags=[tag_constants.SERVING],
        signature_def_map={
            signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY: signature
        })
    builder.save()

def compile_model(model, learning_rate):
  model.compile(
      loss='categorical_crossentropy',
      optimizer=keras.optimizers.RMSprop(lr=learning_rate),
      metrics=['accuracy'])
  return model



# Build U-Net model
def get_unet_v2(h, w, chan):
    input_img = Input((h, w, chan))    

    conv1 = conv_block(input_img, 16)
    conv1 = MaxPooling2D((2, 2))(conv1)
    conv2 = conv_block(conv1, 32)
    conv2 = MaxPooling2D((2,2)) (conv2)
    conv3 = conv_block(conv2, 64)
    conv3 = MaxPooling2D((2,2)) (conv3)
    conv4 = conv_block(conv3, 128)
    conv4 = MaxPooling2D((2,2)) (conv4)
    conv5 = conv_block(conv4, 256)
    conv5 = MaxPooling2D((2,2)) (conv5)
    
    conv6 = conv_block(UpSampling2D()(conv5), 128)
    conv6 = concatenate([conv6, conv4], axis=-1)
    conv6 = conv_block(conv6, 128)

    conv7 = conv_block(UpSampling2D()(conv6), 64)
    conv7 = concatenate([conv7, conv3], axis=-1)
    conv7 = conv_block(conv7, 64)

    conv8 = conv_block(UpSampling2D()(conv7), 32)
    conv8 = concatenate([conv8, conv2], axis=-1)
    conv8 = conv_block(conv8, 32)

    conv9 = conv_block(UpSampling2D()(conv8), 16)
    conv9 = concatenate([conv9, conv1], axis=-1)
    conv9 = conv_block(conv9, 16)
    
    conv10 = conv_block(UpSampling2D()(conv9), 16)
    conv10 = conv_block(conv10, 16)

    outputs = Conv2D(2, (1, 1), activation='sigmoid') (conv10)

    model = Model(inputs=[input_img], outputs=[outputs])
    adam = Adam(lr=p.LEARNING_RATE, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    model.compile(optimizer=adam, loss='binary_crossentropy', metrics=[dice_coef])
    return model


def get_unet(h, w, chan):
    input_img = Input((h, w, chan))    
    
    c1 = Conv2D(16, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (input_img)
    c1 = Dropout(0.1) (c1)
    c1 = Conv2D(16, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (c1)
    p1 = MaxPooling2D((2, 2)) (c1)
    
    c2 = Conv2D(32, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (p1)
    c2 = Dropout(0.1) (c2)
    c2 = Conv2D(32, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (c2)
    p2 = MaxPooling2D((2, 2)) (c2)
    
    c3 = Conv2D(64, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (p2)
    c3 = Dropout(0.2) (c3)
    c3 = Conv2D(64, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (c3)
    p3 = MaxPooling2D((2, 2)) (c3)
    
    c4 = Conv2D(128, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (p3)
    c4 = Dropout(0.2) (c4)
    c4 = Conv2D(128, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (c4)
    p4 = MaxPooling2D(pool_size=(2, 2)) (c4)
    
    c5 = Conv2D(256, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (p4)
    c5 = Dropout(0.3) (c5)
    c5 = Conv2D(256, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (c5)
    
    u6 = Conv2DTranspose(128, (2, 2), strides=(2, 2), padding='same') (c5)
    u6 = concatenate([u6, c4])
    c6 = Conv2D(128, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (u6)
    c6 = Dropout(0.2) (c6)
    c6 = Conv2D(128, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (c6)
    
    u7 = Conv2DTranspose(64, (2, 2), strides=(2, 2), padding='same') (c6)
    u7 = concatenate([u7, c3])
    c7 = Conv2D(64, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (u7)
    c7 = Dropout(0.2) (c7)
    c7 = Conv2D(64, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (c7)
    
    u8 = Conv2DTranspose(32, (2, 2), strides=(2, 2), padding='same') (c7)
    u8 = concatenate([u8, c2])
    c8 = Conv2D(32, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (u8)
    c8 = Dropout(0.1) (c8)
    c8 = Conv2D(32, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (c8)
    
    u9 = Conv2DTranspose(16, (2, 2), strides=(2, 2), padding='same') (c8)
    u9 = concatenate([u9, c1], axis=3)
    c9 = Conv2D(16, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (u9)
    c9 = Dropout(0.1) (c9)
    c9 = Conv2D(16, (3, 3), activation='elu', kernel_initializer='he_normal', padding='same') (c9)
    
    outputs = Conv2D(2, (1, 1), activation='sigmoid') (c9)
    
    model = Model(inputs=[input_img], outputs=[outputs])
    optimizer = Adam(lr=0.0001, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    model.compile(optimizer=optimizer, loss='binary_crossentropy', metrics=[dice_coef])
    return model


def get_densenet121_unet_softmax(input_shape, weights='imagenet'):
    blocks = [6, 12, 24, 16]
#    img_input = Input(input_shape + (4,))
    img_input = Input(input_shape)
    
    x = ZeroPadding2D(padding=((3, 3), (3, 3)))(img_input)
    x = Conv2D(64, 7, strides=2, use_bias=False, name='conv1/conv')(x)
    x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5,
                           name='conv1/bn')(x)
    x = Activation('relu', name='conv1/relu')(x)
    conv1 = x
    x = ZeroPadding2D(padding=((1, 1), (1, 1)))(x)
    x = MaxPooling2D(3, strides=2, name='pool1')(x)
    x = dense_block(x, blocks[0], name='conv2')
    conv2 = x
    x = transition_block(x, 0.5, name='pool2')
    x = dense_block(x, blocks[1], name='conv3')
    conv3 = x
    x = transition_block(x, 0.5, name='pool3')
    x = dense_block(x, blocks[2], name='conv4')
    conv4 = x
    x = transition_block(x, 0.5, name='pool4')
    x = dense_block(x, blocks[3], name='conv5')
    x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5,
                           name='bn')(x)
    conv5 = x 
    
    conv6 = conv_block(UpSampling2D()(conv5), 320)
    conv6 = concatenate([conv6, conv4], axis=-1)
    conv6 = conv_block(conv6, 320)

    conv7 = conv_block(UpSampling2D()(conv6), 256)
    conv7 = concatenate([conv7, conv3], axis=-1)
    conv7 = conv_block(conv7, 256)

    conv8 = conv_block(UpSampling2D()(conv7), 128)
    conv8 = concatenate([conv8, conv2], axis=-1)
    conv8 = conv_block(conv8, 128)

    conv9 = conv_block(UpSampling2D()(conv8), 96)
    conv9 = concatenate([conv9, conv1], axis=-1)
    conv9 = conv_block(conv9, 96)

    conv10 = conv_block(UpSampling2D()(conv9), 64)
    conv10 = conv_block(conv10, 64)
    res = Conv2D(2, (1, 1), activation='softmax')(conv10)
    model = Model(img_input, res)
    
    if weights == 'imagenet':
#        densenet = DenseNet121(input_shape=input_shape + (3,), weights=weights, include_top=False)
        densenet = DenseNet121(input_shape=input_shape, weights=weights, include_top=False)
        w0 = densenet.layers[2].get_weights()
        w = model.layers[2].get_weights()
        w[0][:, :, [0, 1, 2], :] = 0.9 * w0[0][:, :, :3, :]
        # Fourth channel? 
#        w[0][:, :, 3, :] = 0.1 * w0[0][:, :, 1, :]
        model.layers[2].set_weights(w)
        for i in range(3, len(densenet.layers)):
            model.layers[i].set_weights(densenet.layers[i].get_weights())
            model.layers[i].trainable = False
    optimizer = Adam(lr=3e-4, amsgrad=True)
    model.compile(loss=softmax_dice_loss,
        optimizer=optimizer,
#        metrics=[dice_coef_rounded_ch0, dice_coef_rounded_ch1, metrics.categorical_crossentropy])
        metrics=[dice_coef_rounded_ch0, dice_coef_rounded_ch1])

    return model

def get_inception_resnet_v2_unet_softmax(input_shape, weights='imagenet'):
#    inp = Input(input_shape + (4,))
    inp = Input(input_shape)
    # Stem block: 35 x 35 x 192
    x = conv2d_bn(inp, 32, 3, strides=2, padding='same')
    x = conv2d_bn(x, 32, 3, padding='same')
    x = conv2d_bn(x, 64, 3)
    conv1 = x
    x = MaxPooling2D(3, strides=2, padding='same')(x)
    x = conv2d_bn(x, 80, 1, padding='same')
    x = conv2d_bn(x, 192, 3, padding='same')
    conv2 = x
    x = MaxPooling2D(3, strides=2, padding='same')(x)

    # Mixed 5b (Inception-A block): 35 x 35 x 320
    branch_0 = conv2d_bn(x, 96, 1)
    branch_1 = conv2d_bn(x, 48, 1)
    branch_1 = conv2d_bn(branch_1, 64, 5)
    branch_2 = conv2d_bn(x, 64, 1)
    branch_2 = conv2d_bn(branch_2, 96, 3)
    branch_2 = conv2d_bn(branch_2, 96, 3)
    branch_pool = AveragePooling2D(3, strides=1, padding='same')(x)
    branch_pool = conv2d_bn(branch_pool, 64, 1)
    branches = [branch_0, branch_1, branch_2, branch_pool]
#    channel_axis = 1 if K.image_data_format() == 'channels_first' else 3
    channel_axis = 3
    x = Concatenate(axis=channel_axis, name='mixed_5b')(branches)

    # 10x block35 (Inception-ResNet-A block): 35 x 35 x 320
    for block_idx in range(1, 11):
        x = inception_resnet_block(x,
                                   scale=0.17,
                                   block_type='block35',
                                   block_idx=block_idx)
    conv3 = x
    # Mixed 6a (Reduction-A block): 17 x 17 x 1088
    branch_0 = conv2d_bn(x, 384, 3, strides=2, padding='same')
    branch_1 = conv2d_bn(x, 256, 1)
    branch_1 = conv2d_bn(branch_1, 256, 3)
    branch_1 = conv2d_bn(branch_1, 384, 3, strides=2, padding='same')
    branch_pool = MaxPooling2D(3, strides=2, padding='same')(x)
    branches = [branch_0, branch_1, branch_pool]
    x = Concatenate(axis=channel_axis, name='mixed_6a')(branches)

    # 20x block17 (Inception-ResNet-B block): 17 x 17 x 1088
    for block_idx in range(1, 21):
        x = inception_resnet_block(x,
                                   scale=0.1,
                                   block_type='block17',
                                   block_idx=block_idx)
    conv4 = x
    # Mixed 7a (Reduction-B block): 8 x 8 x 2080
    branch_0 = conv2d_bn(x, 256, 1)
    branch_0 = conv2d_bn(branch_0, 384, 3, strides=2, padding='same')
    branch_1 = conv2d_bn(x, 256, 1)
    branch_1 = conv2d_bn(branch_1, 288, 3, strides=2, padding='same')
    branch_2 = conv2d_bn(x, 256, 1)
    branch_2 = conv2d_bn(branch_2, 288, 3)
    branch_2 = conv2d_bn(branch_2, 320, 3, strides=2, padding='same')
    branch_pool = MaxPooling2D(3, strides=2, padding='same')(x)
    branches = [branch_0, branch_1, branch_2, branch_pool]
    x = Concatenate(axis=channel_axis, name='mixed_7a')(branches)

    # 10x block8 (Inception-ResNet-C block): 8 x 8 x 2080
    for block_idx in range(1, 10):
        x = inception_resnet_block(x,
                                   scale=0.2,
                                   block_type='block8',
                                   block_idx=block_idx)
    x = inception_resnet_block(x,
                               scale=1.,
                               activation=None,
                               block_type='block8',
                               block_idx=10)

    # Final convolution block: 8 x 8 x 1536
    x = conv2d_bn(x, 1536, 1, name='conv_7b')
    conv5 = x
    
    conv6 = conv_block(UpSampling2D()(conv5), 320)
    conv6 = concatenate([conv6, conv4], axis=-1)
    conv6 = conv_block(conv6, 320)

    conv7 = conv_block(UpSampling2D()(conv6), 256)
    conv7 = concatenate([conv7, conv3], axis=-1)  
    conv7 = conv_block(conv7, 256)

    conv8 = conv_block(UpSampling2D()(conv7), 128)
    conv8 = concatenate([conv8, conv2], axis=-1)
    conv8 = conv_block(conv8, 128)

    conv9 = conv_block(UpSampling2D()(conv8), 96)
    conv9 = concatenate([conv9, conv1], axis=-1)
    conv9 = conv_block(conv9, 96)

    conv10 = conv_block(UpSampling2D()(conv9), 64)
    conv10 = conv_block(conv10, 64)
    res = Conv2D(2, (1, 1), activation='softmax')(conv10)
    
    model = Model(inp, res)
    
    if weights == 'imagenet':
#        inception_resnet_v2 = InceptionResNetV2(weights=weights, include_top=False, input_shape=input_shape + (3,))
        inception_resnet_v2 = InceptionResNetV2(weights=weights, include_top=False, input_shape=input_shape)
        for i in range(2, len(inception_resnet_v2.layers)-1):
            model.layers[i].set_weights(inception_resnet_v2.layers[i].get_weights())
            model.layers[i].trainable = False
    optimizer = RMSprop( lr=0.001, decay=float(0.0) )
    model.compile(loss=make_loss('bce_dice'),
          optimizer=optimizer,
          metrics=[binary_crossentropy, hard_dice_coef_ch1])
        
    return model


