# Copyright 2017 The TensorFlow Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""This code implements a Feed forward neural network using Keras API.

TO DO:
  Test saved model, downloaded hdf5
    Write script to test in python, that'd be fastest
  Split train, eval, and test data, avoid leaking
  Don't use augmented data for eval
  Try with 'fit' instead of fit_generator so I can use histograms
  Try with resnet
  
"""

import argparse
import glob
import os
import numpy as np
from io import BytesIO

from keras.callbacks import Callback
from keras.callbacks import ModelCheckpoint
from keras.callbacks import TensorBoard
from keras.models import load_model

from tensorflow.contrib.training.python.training import hparam
from tensorflow.python.lib.io import file_io

import trainer.param as p
from trainer.model import get_unet, get_unet_v2, get_densenet121_unet_softmax, get_inception_resnet_v2_unet_softmax, compile_model
from trainer.loss import generator, to_savedmodel

# CHUNK_SIZE specifies the number of lines
# to read in case the file is very large




class ContinuousEval(Callback):
  """Continuous eval callback to evaluate the checkpoint once
     every so many epochs.
  """

  def __init__(self,
               eval_frequency,
               eval_files,
               learning_rate,
               job_dir,
               steps=1000):
    self.eval_files = eval_files
    self.eval_frequency = eval_frequency
    self.learning_rate = learning_rate
    self.job_dir = job_dir
    self.steps = steps
    
  def on_epoch_begin(self, epoch, logs={}):
    """Compile and save model."""
    if epoch > 0 and epoch % self.eval_frequency == 0:
      # Unhappy hack to work around h5py not being able to write to GCS.
      # Force snapshots and saves to local filesystem, then copy them over to GCS.
      model_path_glob = 'checkpoint.*'
      if not self.job_dir.startswith('gs://'):
        model_path_glob = os.path.join(self.job_dir, model_path_glob)
      checkpoints = glob.glob(model_path_glob)
      if len(checkpoints) > 0:
        checkpoints.sort()
#        u_model = load_model(checkpoints[-1])
#        u_model = compile_model(u_model, self.learning_rate)
#        loss, acc = u_model.evaluate_generator(
#            generator(self.eval_files, hparams.eval_batch_size),
#            steps=self.steps)
#        print('\nEvaluation epoch[{}] metrics[{:.2f}, {:.2f}] {}'.format(
#            epoch, loss, acc, u_model.metrics_names))
        if self.job_dir.startswith('gs://'):
          copy_file_to_gcs(self.job_dir, checkpoints[-1])
      else:
        print('\nEvaluation epoch[{}] (no checkpoints found)'.format(epoch))

    


def train_and_evaluate(hparams):
#  unet_model = get_inception_resnet_v2_unet_softmax(p.INPUT_SHAPE, weights='imagenet')
  
  f = BytesIO(file_io.read_file_to_string(hparams.X_train_str, binary_mode=True))
  X_train = np.load(f)
  f = BytesIO(file_io.read_file_to_string(hparams.Y_train_str, binary_mode=True))
  Y_train = np.load(f)
  f = BytesIO(file_io.read_file_to_string(hparams.X_val_str, binary_mode=True))
  X_val = np.load(f)
  f = BytesIO(file_io.read_file_to_string(hparams.Y_val_str, binary_mode=True))
  Y_val = np.load(f)
  f = BytesIO(file_io.read_file_to_string(hparams.X_test_str, binary_mode=True))
  X_test = np.load(f)
  f = BytesIO(file_io.read_file_to_string(hparams.Y_test_str, binary_mode=True))
  Y_test = np.load(f)
  
#  unet_model = get_unet_v2(p.IMG_HEIGHT, p.IMG_WIDTH, p.IMG_CHANNELS)
  unet_model = get_inception_resnet_v2_unet_softmax(p.INPUT_SHAPE, weights='imagenet')
  try:
    os.makedirs(hparams.job_dir)
  except:
    pass

  # Unhappy hack to workaround h5py not being able to write to GCS.
  # Force snapshots and saves to local filesystem, then copy them over to GCS.
  checkpoint_path = p.CHECKPOINT_FILE_PATH
  if not hparams.job_dir.startswith('gs://'):
    checkpoint_path = os.path.join(hparams.job_dir, checkpoint_path)

  # Model checkpoint callback.
  checkpoint = ModelCheckpoint(
      checkpoint_path,
      monitor='val_loss',
      verbose=1,
      mode='min')

  # Continuous eval callback.
  evaluation = ContinuousEval(hparams.eval_frequency, (X_test, Y_test),
                              hparams.learning_rate, hparams.job_dir)

  # Tensorboard logs callback.
  tb_log = TensorBoard(
      log_dir=os.path.join(hparams.job_dir, 'logs'),
      histogram_freq=1,
      write_graph=True,
      embeddings_freq=0)

  callbacks = [checkpoint, evaluation, tb_log]

#  unet_model.fit_generator(
#      generator(X_train, Y_train, hparams.train_batch_size),
#      validation_data = generator(X_test, Y_test, hparams.eval_batch_size),
#      validation_steps = hparams.eval_steps,
#      steps_per_epoch=hparams.train_steps,
#      epochs=hparams.epochs,
#      callbacks=callbacks)
#  
  results = unet_model.fit(X_train, Y_train, 
                           validation_data = (X_val, Y_val),
                           batch_size=hparams.train_batch_size, 
                           epochs=hparams.epochs, 
                           callbacks=callbacks)


  # Unhappy hack to workaround h5py not being able to write to GCS.
  # Force snapshots and saves to local filesystem, then copy them over to GCS.
  if hparams.job_dir.startswith('gs://'):
    unet_model.save(p.UNET_MODEL)
    copy_file_to_gcs(hparams.job_dir, p.UNET_MODEL)
  else:
    unet_model.save(os.path.join(hparams.job_dir, p.UNET_MODEL))

  # Convert the Keras model to TensorFlow SavedModel.
  to_savedmodel(unet_model, os.path.join(hparams.job_dir, 'export'))


# h5py workaround: copy local models over to GCS if the job_dir is GCS.
def copy_file_to_gcs(job_dir, file_path):
  with file_io.FileIO(file_path, mode='rb') as input_f:
    with file_io.FileIO(
        os.path.join(job_dir, file_path), mode='w+') as output_f:
      output_f.write(input_f.read())

if __name__ == '__main__':
  parser = argparse.ArgumentParser()
  parser.add_argument(
      '--X-train-str',
      nargs='+',
      help='Training file local or GCS',
      default='gs://petridish/X_train.npy')
  parser.add_argument(
      '--Y-train-str',
      nargs='+',
      help='Training file local or GCS',
      default='gs://petridish/Y_train.npy')
  parser.add_argument(
      '--X-val-str',
      nargs='+',
      help='Training file local or GCS',
      default='gs://petridish/X_val.npy')
  parser.add_argument(
      '--Y-val-str',
      nargs='+',
      help='Training file local or GCS',
      default='gs://petridish/Y_val.npy')
  parser.add_argument(
      '--X-test-str',
      nargs='+',
      help='Training file local or GCS',
      default='gs://petridish/X_test.npy')
  parser.add_argument(
      '--Y-test-str',
      nargs='+',
      help='Training file local or GCS',
      default='gs://petridish/Y_test.npy')
  parser.add_argument(
      '--job-dir',
      type=str,
      help='GCS or local dir to write checkpoints and export model',
      default='/tmp/nuclei-keras')
  parser.add_argument(
      '--tb-dir',
      type=str,
      help='GCS or local dir to for tensorboard',
      default='/tmp/nuclei-keras/logs')
  parser.add_argument(
      '--train-steps',
      type=int,
      default=p.TRAIN_STEPS,
      help="""\
        Maximum number of training steps to perform
        Training steps are in the units of training-batch-size.
        So if train-steps is 500 and train-batch-size if 100 then
        at most 500 * 100 training instances will be used to train.""")
  parser.add_argument(
      '--eval-steps',
      help='Number of steps to run evalution for at each checkpoint',
      default=p.EVAL_STEPS,
      type=int)
  parser.add_argument(
      '--train-batch-size',
      type=int,
      default=p.TRAIN_BATCH_SIZE,
      help='Batch size for training steps')
  parser.add_argument(
      '--eval-batch-size',
      type=int,
      default=p.EVAL_BATCH_SIZE,
      help='Batch size for evaluation steps')
  parser.add_argument(
      '--learning-rate',
      type=float,
      default=p.LEARNING_RATE,
      help='Learning rate for model')
  parser.add_argument(
      '--eval-frequency',
      default=p.EVAL_FREQUENCY,
      help='Perform one evaluation per n epochs')
  parser.add_argument(
      '--eval-num-epochs',
      type=int,
      default=p.EVAL_NUM_EPOCHS,
      help='Number of epochs during evaluation')
  parser.add_argument(
      '--epochs',
      type=int,
      default=p.EPOCHS,
      help='Maximum number of epochs on which to train')
  parser.add_argument(
      '--checkpoint-epochs',
      type=int,
      default=p.CHECKPOINT_EPOCHS,
      help='Checkpoint per n training epochs')

  args, _ = parser.parse_known_args()

  hparams = hparam.HParams(**args.__dict__)
  train_and_evaluate(hparams)