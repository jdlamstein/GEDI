#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Sep 22 23:04:45 2018

@author: joshualamstein
"""

import numpy as np
 
def get_bounding_param( min_side, max_side, seed):
    np.random.seed(seed)
    side_length = np.random.beta(a = 3, b = 1, size = 200)
    side_length = np.round(np.interp(side_length, [0,1], [min_side, max_side]))
    side_length = np.uint8(side_length)
#    side_length = np.random.randint(min_side, max_side, size = 100)
    return side_length

TESTING_BOOL = False
SAVE_BOOL = False
LOAD_TRAIN = True
LOAD_ALL = False

FOLDER = '/Users/joshualamstein/.kaggle/competitions/data_bowl/kaggle-dsbowl-2018-dataset-fixes-master/stage1_train'
SAMPLE_IM= FOLDER + '/0a7d30b252359a10fd298b638b90cb9ada3acced4e0c0e5a3692013f432ee4e9/images/0a7d30b252359a10fd298b638b90cb9ada3acced4e0c0e5a3692013f432ee4e9.png'
SAMPLE_MASK = FOLDER + '/0a7d30b252359a10fd298b638b90cb9ada3acced4e0c0e5a3692013f432ee4e9/masks/47b619fab80e12d48e90530ce859e4b02c46cc82198745bcceafe9b18915931a.png'
TARGET_SIZE = (256,256)
IMG_HEIGHT = 256
IMG_WIDTH = 256
IMG_CHANNELS = 3
IM_CHANNEL = (3,)
MASK_CHANNEL = (3,)
INPUT_SHAPE = (IMG_HEIGHT, IMG_WIDTH, IMG_CHANNELS)

MIN_SIDE = 30
MAX_SIDE = 254
EPS = 1e-3
SEED = 42
PROB = 0.05
TESTING_LENGTH = 5
MULT_PER_IM = 14
MULT_SAMPLE = 1
LEARNING_RATE = 0.0001

ALPHA = 2
SIGMA = 0.08
ALPHA_AFFINE = 0.08

TEST_SIZE = 0.2
EPOCHS = 100
TRAIN_BATCH_SIZE = 16 # 7436 - 2 2 11 13 13
EVAL_BATCH_SIZE = 30 # 1860 - 2 2 3 5 31
TRAIN_STEPS = 338 # 338
EVAL_STEPS = 62 # 100
EVAL_FREQUENCY = 10
EVAL_NUM_EPOCHS = 1
CHECKPOINT_EPOCHS = 10

IDENTIFIER = 'resnet1'
PATHNAME = 'processed_dataset_' + IDENTIFIER
SAVEFILENAME = PATHNAME + '.h5'
LOADFILENAME = 'processed_dataset_BNonly_aug.h5'
SAVEPREDNAME = 'PREDICT_' + SAVEFILENAME
SAVEIMGSTR = PATHNAME + '_test_vs_pred.png'
LOADMODELPATH = '/Users/joshualamstein/Desktop/pyFiles/nuclei_segmentation/saved_nuclei_models/' + 'model_weights.06-0.08.hdf5'

CHECKPOINT_FILE_PATH = 'checkpoint.{epoch:02d}.hdf5'
UNET_MODEL = 'resnet_gcloud.hdf5'

SIDE_LENGTH = get_bounding_param( MIN_SIDE, MAX_SIDE, SEED)

